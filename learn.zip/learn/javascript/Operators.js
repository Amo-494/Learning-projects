document.write("hello wo ");
function missingno(numbers){
    var missing = -1;

    for( i = 0; i<= numbers.length; i++){
        if(numbers.indexOf(i)=== -1){
            missing = i;
        }
    }
     return missing;
}
var numbers = [3,8,7,5,6,12,9,2,15,18,20,1,10,13,11,16,14,17,19];

console.log(missingno(numbers)); 