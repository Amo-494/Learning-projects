#Define a list of names
names = ["ron","tommy","harry","abel"]

print(names[0])

names.append("brian")

names.sort()

print(names)