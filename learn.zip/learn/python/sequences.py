from tkinter.font import names


names = ["Harry","Tommy","Abel"]

print(names[0])