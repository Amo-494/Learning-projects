#Create and empty set
from typing import Set


s = set()

#Add elements to the set
s.add(1)
s.add(2)
s.add(3)
s.add(4)

s.remove(2)
print(f"the set has {len(s)} elements.")