name = input("Name:")
print(f"hello,{name}")