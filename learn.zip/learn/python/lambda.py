people = [
    {"name":"harry", "house": "gryffindor"},
    {"name": "brian", "house": "chania"},
    {"name": "tommy", "house" : "kizito"}
]


people.sort(key= lambda person: person["name"])

print(people)