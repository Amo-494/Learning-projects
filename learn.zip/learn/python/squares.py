import functions

for i in range(10):
    print(f"the square of {i} is {functions.square(i)}")