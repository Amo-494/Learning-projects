for i in range(6):
    print (i)