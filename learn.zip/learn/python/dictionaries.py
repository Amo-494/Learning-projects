houses = {"harry":"gryffindor","draco":"slytherin"}

houses["hermaine"]= "gryffindor"
print(houses["hermaine"])